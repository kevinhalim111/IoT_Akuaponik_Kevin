package com.example.iot_akuaponik_kevin;

import androidx.appcompat.app.AppCompatActivity;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.iot_akuaponik_kevin.R;

import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {

    Button btSignin, btSignup;
    TextView welcomeTxt;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);



        Animation aFade = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.fade_in);

        btSignin = findViewById(R.id.btSignin);
        btSignup = findViewById(R.id.btSignup);
        welcomeTxt = findViewById(R.id.textViewWelcome);

        btSignin.setVisibility(View.VISIBLE);
        btSignin.startAnimation(aFade);

        btSignup.setVisibility(View.VISIBLE);
        btSignup.startAnimation(aFade);

        welcomeTxt.setVisibility(View.VISIBLE);
        welcomeTxt.startAnimation(aFade);

        btSignin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, login.class));
            }
        });

        btSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, register.class));
            }
        });
    }

    private void scheduleSensorWorker() {
        PeriodicWorkRequest sensorWorkRequest = new PeriodicWorkRequest.Builder(SensorWorker.class, 1, TimeUnit.MINUTES)
                .addTag("sensorWorkTag")
                .build();

        WorkManager.getInstance(this).enqueue(sensorWorkRequest);
    }
}
