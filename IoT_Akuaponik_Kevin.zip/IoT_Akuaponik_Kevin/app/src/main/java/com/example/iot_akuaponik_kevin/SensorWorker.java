package com.example.iot_akuaponik_kevin;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.TimeUnit;

public class SensorWorker extends Worker {

    private static final String SENSOR_ENDPOINT = "http://192.168.1.8:3000/sensor";
    private static final String CHANNEL_ID = "sensor_notifications";
    private static final int NOTIFICATION_ID_OXYGEN = 1;
    private static final int NOTIFICATION_ID_TURBIDITY = 2;

    public SensorWorker(@NonNull Context context, @NonNull WorkerParameters workerParams) {
        super(context, workerParams);
        createNotificationChannel();
    }

    @NonNull
    @Override
    public Result doWork() {
        SharedPreferences sharedPreferences = getApplicationContext().getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        String idKolam = sharedPreferences.getString("idkolam", null);

        if (idKolam != null) {
            try {
                URL url = new URL(SENSOR_ENDPOINT + "?idkolam=" + idKolam);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");

                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();

                Log.v("SensorWorker", "Server response: " + response.toString());

                processSensorData(response.toString());

                return Result.success();
            } catch (IOException e) {
                e.printStackTrace();
                Log.e("SensorWorker", "Failed to fetch sensor data: " + e.getMessage());
                return Result.failure();
            }
        } else {
            Log.e("SensorWorker", "ID Kolam not found!");
            return Result.failure();
        }
    }

    private void processSensorData(String jsonData) {
        try {
            JSONArray jsonArray = new JSONArray(jsonData);
            if (jsonArray.length() > 0) {
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    String oxygenValue = jsonObject.optString("Oksigen", "0");
                    String turbidityValue = jsonObject.optString("Kekeruhan", "0");

                    float oxygenValueFloat = Float.parseFloat(oxygenValue);
                    float turbidityValueFloat = Float.parseFloat(turbidityValue);

                    if (oxygenValueFloat < 5) {
                        showNotification("Oxygen Alert", "Oxygen level is below 5", NOTIFICATION_ID_OXYGEN);
                    }
                    if (turbidityValueFloat < 5) {
                        showNotification("Turbidity Alert", "Turbidity level is below 5", NOTIFICATION_ID_TURBIDITY);
                    }

                }
            } else {
                Log.v("SensorWorker", "No sensor data found.");
            }
        } catch (JSONException e) {
            e.printStackTrace();
            Log.e("SensorWorker", "Error processing sensor data: " + e.getMessage());
        }
    }

    private void showNotification(String title, String text, int notificationId) {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_ID)
                .setSmallIcon(R.drawable.shower_96px)
                .setContentTitle(title)
                .setContentText(text)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true);

        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(getApplicationContext());
        notificationManager.notify(notificationId, builder.build());
        Log.v("SensorWorker", "Notification shown: " + title);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Sensor Notifications";
            String description = "Notifications for sensor data";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);
            NotificationManager notificationManager = getApplicationContext().getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
            Log.v("SensorWorker", "Notification channel created.");
        }
    }

    public static void scheduleSensorWorker(Context context) {
        PeriodicWorkRequest sensorWorkRequest = new PeriodicWorkRequest.Builder(SensorWorker.class, 1, TimeUnit.MINUTES)
                .build();
        WorkManager.getInstance(context).enqueue(sensorWorkRequest);
        Log.v("SensorWorker", "Sensor worker scheduled.");
    }
}
