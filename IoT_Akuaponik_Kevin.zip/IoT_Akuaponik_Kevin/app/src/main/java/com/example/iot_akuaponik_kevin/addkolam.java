package com.example.iot_akuaponik_kevin;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class addkolam extends AppCompatActivity {

    private SharedPreferences sharedPreferences;
    private String idAkuaponik; // Mengganti username menjadi idAkuaponik

    private static final String SERVER_IP = "192.168.195.120";
    private static final String ADD_KOLAM_URL = "http://" + SERVER_IP + ":3000/kolam";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.addkolam); // Asumsikan Anda memiliki layout bernama 'kolam'

        // Inisialisasi SharedPreferences di dalam onCreate()
        sharedPreferences = getSharedPreferences("loginPrefs", Context.MODE_PRIVATE);
        Log.v("SharedPreferences", "SharedPreferences initialized");

        // Mendapatkan ID akuaponik dari intent
        idAkuaponik = getIntent().getStringExtra("idAkuaponik");

        final EditText editTextKolamName = findViewById(R.id.editText_kolam_name);
        Button saveKolamButton = findViewById(R.id.button_save_kolam);

        saveKolamButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String kolamName = editTextKolamName.getText().toString();
                if (!kolamName.isEmpty()) {
                    editTextKolamName.setEnabled(false); // Menonaktifkan EditText
                    saveKolamButton.setEnabled(false); // Menonaktifkan tombol Save
                    sendKolamDataToServer(kolamName, idAkuaponik);
                } else {
                    Toast.makeText(addkolam.this, "Nama kolam tidak boleh kosong", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Mengaktifkan kembali EditText dan tombol Save ketika activity ditampilkan kembali
        EditText editTextKolamName = findViewById(R.id.editText_kolam_name);
        Button saveKolamButton = findViewById(R.id.button_save_kolam);
        editTextKolamName.setEnabled(true);
        saveKolamButton.setEnabled(true);
    }

    private void sendKolamDataToServer(String name, String idAkuaponik) {
        SendKolamDataTask task = new SendKolamDataTask();
        task.execute(name, idAkuaponik);
    }

    private class SendKolamDataTask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... params) {
            String kolamName = params[0];
            String idAkuaponik = params[1];
            String response = "";

            try {
                URL url = new URL(ADD_KOLAM_URL);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setRequestProperty("Content-Type", "application/json");
                connection.setDoOutput(true);

                // Kirim data kolam bersama dengan idAkuaponik
                String requestBody = "{\"nama_kolam\":\"" + kolamName + "\",\"idakuaponik\":\"" + idAkuaponik + "\"}";

                OutputStream outputStream = connection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(outputStream));
                writer.write(requestBody);
                writer.flush();
                writer.close();

                int responseCode = connection.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK || responseCode == HttpURLConnection.HTTP_CREATED) {
                    response = "Kolam saved successfully";
                } else {
                    response = "Failed to save kolam: Server error (" + responseCode + ")";
                }
            } catch (IOException e) {
                e.printStackTrace();
                response = "Error: " + e.getMessage();
            }

            return response;
        }

        @Override
        protected void onPostExecute(String result) {
            Toast.makeText(addkolam.this, result, Toast.LENGTH_SHORT).show();
            Log.v("Response", "Server response: " + result);
            // Jika kolam berhasil disimpan, kembali ke activity sebelumnya
            if (result.equals("Kolam saved successfully")) {
                finish(); // Menutup activity addkolam
            }
        }
    }
}