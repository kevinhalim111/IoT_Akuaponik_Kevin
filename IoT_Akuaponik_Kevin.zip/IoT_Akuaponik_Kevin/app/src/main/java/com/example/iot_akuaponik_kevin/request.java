package com.example.iot_akuaponik_kevin;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class request extends AppCompatActivity {

    private LinearLayout containerLayout;
    private String username; // Menyimpan username dari Shared Preference

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.request);

        Log.v("Request", "onCreate");

        // Inisialisasi container layout
        containerLayout = findViewById(R.id.dynamic);

        // Mengambil username dari Shared Preference
        SharedPreferences sharedPreferences = getSharedPreferences("loginPrefs", Context.MODE_PRIVATE);
        username = sharedPreferences.getString("username", "");
        Log.v("Request", "Username from SharedPreferences: " + username);

        // Mulai task untuk mengambil data request dari server
        new FetchRequestDataTask().execute();
    }

    // AsyncTask untuk mengambil data request dari server
    private class FetchRequestDataTask extends AsyncTask<Void, Void, String> {

        @Override
        protected String doInBackground(Void... voids) {
            Log.v("FetchRequestDataTask", "doInBackground");

            // URL endpoint untuk mengambil data request dari server berdasarkan username
            String apiUrl = "http://192.168.195.120/request?username=" + username;

            try {
                // Buat koneksi HTTP
                URL url = new URL(apiUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");

                // Baca respons dari server
                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();

                // Kembalikan data JSON sebagai string
                return response.toString();
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(String jsonData) {
            Log.v("FetchRequestDataTask", "onPostExecute");

            if (jsonData != null) {
                try {
                    // Parsing data JSON
                    JSONArray requestsArray = new JSONArray(jsonData);

                    for (int i = 0; i < requestsArray.length(); i++) {
                        JSONObject requestObj = requestsArray.getJSONObject(i);
                        String requestingUsername = requestObj.getString("requestingUsername");
                        String requestMessage = requestObj.getString("requestMessage");

                        Button button = new Button(request.this);
                        button.setText("Request from " + requestingUsername);
                        button.setTag(requestMessage); // Set the requestMessage as the tag
                        button.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                String requestMessage = (String) view.getTag(); // Retrieve the requestMessage from the tag

                                // Intent untuk berpindah ke kelas yang sesuai dan mengirim data tambahan
                                Intent intent = new Intent(request.this, login.class);
                                intent.putExtra("requestMessage", requestMessage); // Mengirim requestMessage ke kelas lain
                                startActivity(intent); // Mulai aktivitas baru
                            }
                        });
                        containerLayout.addView(button);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } else {
                // Handle kesalahan saat mengambil data request
                Toast.makeText(request.this, "Failed to fetch request data", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
