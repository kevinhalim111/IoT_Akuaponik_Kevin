package com.example.iot_akuaponik_kevin;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class solenoid extends Activity {

    private ListView solenoidListView;
    private SolenoidAdapter solenoidAdapter;
    private ArrayList<Solenoid> solenoidList;
    private String idKolam;
    private static final String SOLENOID_ENDPOINT = "http://192.168.195.120:3000/solenoid";
    private Switch solenoidSwitch;
    private boolean isInitialFetch = true;  // Flag to prevent sending POST request on initial fetch

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_solenoid);

        solenoidListView = findViewById(R.id.solenoidListView);
        solenoidList = new ArrayList<>();
        solenoidAdapter = new SolenoidAdapter(this, solenoidList);
        solenoidListView.setAdapter(solenoidAdapter);

        solenoidSwitch = findViewById(R.id.solenoidSwitch);

        solenoidSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (!isInitialFetch) {
                sendSolenoidStatusToServer(isChecked);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Get the idkolam from the intent
        Intent intent = getIntent();
        idKolam = intent.getStringExtra("idkolam");

        Log.v("SOLENOID_TAG", "ID Kolam: " + idKolam); // Tambahkan log untuk menampilkan idkolam

        // Fetch solenoid data and update switch when activity resumes
        if (idKolam != null) {
            fetchSolenoidDataFromServer();
        } else {
            Toast.makeText(this, "ID Kolam not found!", Toast.LENGTH_SHORT).show();
        }
    }

    private void sendSolenoidStatusToServer(boolean isChecked) {
        new SendSolenoidStatusTask().execute(isChecked);
    }

    private void fetchSolenoidDataFromServer() {
        new FetchSolenoidDataTask().execute(idKolam);
    }

    private class SendSolenoidStatusTask extends AsyncTask<Boolean, Void, Boolean> {
        @Override
        protected Boolean doInBackground(Boolean... params) {
            boolean value = params[0];
            String apiUrl = SOLENOID_ENDPOINT + "/" + idKolam;

            try {
                URL url = new URL(apiUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setRequestProperty("Content-Type", "application/json");
                connection.setDoOutput(true);

                JSONObject postData = new JSONObject();
                postData.put("value", value ? 1 : 0); // Mengirim 1 untuk "on" dan 0 untuk "off"

                DataOutputStream outputStream = new DataOutputStream(connection.getOutputStream());
                outputStream.writeBytes(postData.toString());
                outputStream.flush();
                outputStream.close();

                int responseCode = connection.getResponseCode();
                Log.v("SOLENOID_TAG", "Response code: " + responseCode); // Tambahkan log untuk menampilkan response code dari server
                return responseCode == 200 || responseCode == 201; // Menganggap 201 juga sebagai response sukses

            } catch (IOException | JSONException e) {
                e.printStackTrace();
                return false;
            }
        }

        @Override
        protected void onPostExecute(Boolean success) {
            if (success) {
                Toast.makeText(solenoid.this, "Solenoid status updated successfully", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(solenoid.this, "Failed to update solenoid status", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private class FetchSolenoidDataTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            String idKolam = params[0];
            String apiUrl = SOLENOID_ENDPOINT + "/" + idKolam;

            try {
                URL url = new URL(apiUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");

                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();

                Log.v("SOLENOID_TAG", "Solenoid data fetched successfully"); // Tambahkan log untuk menampilkan pesan bahwa data solenoid berhasil diambil dari server
                return response.toString();
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(String jsonData) {
            if (jsonData != null) {
                try {
                    JSONArray jsonArray = new JSONArray(jsonData);
                    solenoidList.clear();
                    boolean lastStatus = false;
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        boolean booleanValue = jsonObject.optInt("boolean", -1) == 1;
                        lastStatus = booleanValue;
                        String status = booleanValue ? "on" : "off";
                        String date = jsonObject.optString("Date", "N/A");
                        solenoidList.add(new Solenoid(status, date));
                    }
                    solenoidAdapter.notifyDataSetChanged();
                    isInitialFetch = true;  // Prevent sending POST request when setting switch initially
                    solenoidSwitch.setChecked(lastStatus);  // Set switch based on the latest status
                    isInitialFetch = false;
                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(solenoid.this, "Error parsing data", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(solenoid.this, "Failed to fetch solenoid data", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private class SolenoidAdapter extends ArrayAdapter<Solenoid> {

        public SolenoidAdapter(Activity context, ArrayList<Solenoid> solenoids) {
            super(context, 0, solenoids);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            Solenoid solenoid = getItem(position);

            if (convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.solenoid_list_item, parent, false);
            }

            TextView statusTextView = convertView.findViewById(R.id.solenoidStatus);
            TextView dateTextView = convertView.findViewById(R.id.solenoidDate);

            statusTextView.setText(solenoid.getStatus());
            dateTextView.setText(solenoid.getDate());

            return convertView;
        }
    }

    private class Solenoid {
        private String status;
        private String date;

        public Solenoid(String status, String date) {
            this.status = status;
            this.date = date;
        }

        public String getStatus() {
            return status;
        }

        public String getDate() {
            return date;
        }
    }
}
