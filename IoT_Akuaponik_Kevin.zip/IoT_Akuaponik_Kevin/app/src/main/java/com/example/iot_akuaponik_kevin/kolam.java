package com.example.iot_akuaponik_kevin;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class kolam extends AppCompatActivity {

    private LinearLayout containerLayout;
    private String idAkuaponik;
    private static final String SERVER_IP = "192.168.195.120";
    private static final String DELETE_AKUAPONIK_URL = "http://" + SERVER_IP + ":3000/akuaponik/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.kolam);

        containerLayout = findViewById(R.id.dynamic);

        // Get the id_akuaponik from the intent or SharedPreferences
        Intent intent = getIntent();
        idAkuaponik = intent.getStringExtra("idAkuaponik");

        if (idAkuaponik == null) {
            SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
            idAkuaponik = sharedPreferences.getString("idAkuaponik", null);
        }

        if (idAkuaponik != null) {
            // Save idAkuaponik to SharedPreferences
            SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString("idAkuaponik", idAkuaponik);
            editor.apply();
        } else {
            Toast.makeText(this, "ID Akuaponik not found!", Toast.LENGTH_SHORT).show();
        }

        Log.v("kolam", "Received idakuaponik: " + idAkuaponik);

        // Add action for the delete button
        Button deleteButton = findViewById(R.id.btdelete);
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (idAkuaponik != null) {
                    new DeleteAkuaponikTask(kolam.this).execute(idAkuaponik);
                } else {
                    Toast.makeText(kolam.this, "ID Akuaponik not found!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Add action for the add kolam button
        Button addKolamButton = findViewById(R.id.button_add_kolam);
        addKolamButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Intent to move to AddKolam Activity and send idAkuaponik
                Intent addKolamIntent = new Intent(kolam.this, addkolam.class);
                addKolamIntent.putExtra("idAkuaponik", idAkuaponik);
                startActivity(addKolamIntent);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Check if idAkuaponik is not null before fetching data
        if (idAkuaponik != null) {
            // Clear existing views before adding new ones
            containerLayout.removeAllViews();

            // Start AsyncTask to fetch kolam data based on idAkuaponik
            new FetchKolamDataTask(this).execute(idAkuaponik);
        } else {
            Toast.makeText(this, "ID Akuaponik not found!", Toast.LENGTH_SHORT).show();
        }
    }

    // AsyncTask to fetch kolam data based on idAkuaponik
    @SuppressLint("StaticFieldLeak")
    private class FetchKolamDataTask extends AsyncTask<String, Void, String> {
        private final Context context;

        public FetchKolamDataTask(Context context) {
            this.context = context;
        }

        @Override
        protected String doInBackground(String... params) {
            String id = params[0];
            String apiUrl = "http://" + SERVER_IP + ":3000/kolam/" + id;

            try {
                URL url = new URL(apiUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");

                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();

                return response.toString();
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(String jsonData) {
            if (jsonData != null) {
                try {
                    JSONArray kolamArray = new JSONArray(jsonData);

                    for (int i = 0; i < kolamArray.length(); i++) {
                        JSONObject kolamObj = kolamArray.getJSONObject(i);
                        String namaKolam = kolamObj.getString("nama_kolam");
                        String idKolam = kolamObj.getString("idkolam");

                        Button kolamButton = new Button(context);
                        kolamButton.setText(namaKolam);
                        kolamButton.setTag(idKolam);

                        kolamButton.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                String kolamName = ((Button) v).getText().toString();
                                String kolamId = (String) v.getTag();

                                // Intent to move to sensor Activity and send idKolam and namaKolam
                                Intent intent = new Intent(kolam.this, sensor.class);
                                intent.putExtra("idkolam", kolamId);
                                intent.putExtra("nama_kolam", kolamName);
                                startActivity(intent);
                            }
                        });

                        containerLayout.addView(kolamButton);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(context, "Error parsing data", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(context, "Failed to fetch kolam data", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // AsyncTask to delete akuaponik data based on idAkuaponik
    @SuppressLint("StaticFieldLeak")
    private class DeleteAkuaponikTask extends AsyncTask<String, Void, String> {
        private final Context context;

        public DeleteAkuaponikTask(Context context) {
            this.context = context;
        }

        @Override
        protected String doInBackground(String... params) {
            String id = params[0];
            String apiUrl = DELETE_AKUAPONIK_URL + id;

            try {
                URL url = new URL(apiUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("DELETE");

                int responseCode = connection.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    return "Akuaponik data deleted successfully";
                } else {
                    return "Failed to delete akuaponik data: Server error (" + responseCode + ")";
                }
            } catch (IOException e) {
                e.printStackTrace();
                return "Error: " + e.getMessage();
            }
        }

        @Override
        protected void onPostExecute(String result) {
            Toast.makeText(context, result, Toast.LENGTH_SHORT).show();
            if (result.equals("Akuaponik data deleted successfully")) {
                finish(); // Close the activity after successful deletion
            }
        }
    }
}
