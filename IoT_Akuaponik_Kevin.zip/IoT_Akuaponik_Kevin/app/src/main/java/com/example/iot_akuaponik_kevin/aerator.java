package com.example.iot_akuaponik_kevin;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class aerator extends Activity {

    private ListView aeratorListView;
    private AeratorAdapter aeratorAdapter;
    private ArrayList<Aerator> aeratorList;
    private String idKolam;
    private static final String AERATOR_ENDPOINT = "http://192.168.195.120:3000/aerator";
    private Switch aeratorSwitch;
    private boolean isInitialFetch = true;  // Flag to prevent sending POST request on initial fetch

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aerator);

        aeratorListView = findViewById(R.id.aeratorListView);
        aeratorList = new ArrayList<>();
        aeratorAdapter = new AeratorAdapter(this, aeratorList);
        aeratorListView.setAdapter(aeratorAdapter);

        aeratorSwitch = findViewById(R.id.aeratorSwitch);

        aeratorSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (!isInitialFetch) {
                sendAeratorStatusToServer(isChecked);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Get the idkolam from the intent
        Intent intent = getIntent();
        idKolam = intent.getStringExtra("idkolam");

        Log.v("AERATOR_TAG", "ID Kolam: " + idKolam); // Tambahkan log untuk menampilkan idkolam

        // Fetch aerator data and update switch when activity resumes
        if (idKolam != null) {
            fetchAeratorDataFromServer();
        } else {
            Toast.makeText(this, "ID Kolam not found!", Toast.LENGTH_SHORT).show();
        }
    }

    private void sendAeratorStatusToServer(boolean isChecked) {
        new SendAeratorStatusTask().execute(isChecked);
    }

    private void fetchAeratorDataFromServer() {
        new FetchAeratorDataTask().execute(idKolam);
    }

    private class SendAeratorStatusTask extends AsyncTask<Boolean, Void, Boolean> {
        @Override
        protected Boolean doInBackground(Boolean... params) {
            boolean value = params[0];
            String apiUrl = AERATOR_ENDPOINT + "/" + idKolam;

            try {
                URL url = new URL(apiUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setRequestProperty("Content-Type", "application/json");
                connection.setDoOutput(true);

                JSONObject postData = new JSONObject();
                postData.put("value", value ? 1 : 0); // Mengirim 1 untuk "on" dan 0 untuk "off"

                DataOutputStream outputStream = new DataOutputStream(connection.getOutputStream());
                outputStream.writeBytes(postData.toString());
                outputStream.flush();
                outputStream.close();

                int responseCode = connection.getResponseCode();
                Log.v("AERATOR_TAG", "Response code: " + responseCode); // Tambahkan log untuk menampilkan response code dari server
                return responseCode == 200 || responseCode == 201; // Menganggap 201 juga sebagai response sukses

            } catch (IOException | JSONException e) {
                e.printStackTrace();
                return false;
            }
        }

        @Override
        protected void onPostExecute(Boolean success) {
            if (success) {
                Toast.makeText(aerator.this, "Aerator status updated successfully", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(aerator.this, "Failed to update aerator status", Toast.LENGTH_SHORT).show();
            }
        }
    }


    private class FetchAeratorDataTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            String idKolam = params[0];
            String apiUrl = AERATOR_ENDPOINT + "/" + idKolam;

            try {
                URL url = new URL(apiUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");

                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();

                Log.v("AERATOR_TAG", "Aerator data fetched successfully"); // Tambahkan log untuk menampilkan pesan bahwa data aerator berhasil diambil dari server
                return response.toString();
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(String jsonData) {
            if (jsonData != null) {
                try {
                    JSONArray jsonArray = new JSONArray(jsonData);
                    aeratorList.clear();
                    boolean lastStatus = false;
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        boolean booleanValue = jsonObject.optInt("boolean", -1) == 1;
                        lastStatus = booleanValue;
                        String status = booleanValue ? "on" : "off";
                        String date = jsonObject.optString("Date", "N/A");
                        aeratorList.add(new Aerator(status, date));
                    }
                    aeratorAdapter.notifyDataSetChanged();
                    isInitialFetch = true;  // Prevent sending POST request when setting switch initially
                    aeratorSwitch.setChecked(lastStatus);  // Set switch based on the latest status
                    isInitialFetch = false;
                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(aerator.this, "Error parsing data", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(aerator.this, "Failed to fetch aerator data", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private class AeratorAdapter extends ArrayAdapter<Aerator> {

        public AeratorAdapter(Activity context, ArrayList<Aerator> aerators) {
            super(context, 0, aerators);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            Aerator aerator = getItem(position);

            if (convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.aerator_list_item, parent, false);
            }

            TextView statusTextView = convertView.findViewById(R.id.aeratorStatus);
            TextView dateTextView = convertView.findViewById(R.id.aeratorDate);

            statusTextView.setText(aerator.getStatus());
            dateTextView.setText(aerator.getDate());

            return convertView;
        }
    }

    private class Aerator {
        private String status;
        private String date;

        public Aerator(String status, String date) {
            this.status = status;
            this.date = date;
        }

        public String getStatus() {
            return status;
        }

        public String getDate() {
            return date;
        }
    }
}
