package com.example.iot_akuaponik_kevin;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class login extends AppCompatActivity {

    private EditText editTextUsername;
    private EditText editTextPassword;
    private Button buttonLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Mengecek apakah pengguna sudah login saat aplikasi dimulai
        SharedPreferences sharedPreferences = getSharedPreferences("loginPrefs", Context.MODE_PRIVATE);
        boolean isLoggedIn = sharedPreferences.getBoolean("isLoggedIn", false);
        //Log.v("LoginStatus", "IsLoggedIn: " + isLoggedIn);
        if (isLoggedIn) {
            // Jika pengguna sudah login, lanjutkan ke halaman berikutnya
            Intent intent = new Intent(this, Farm.class);
            startActivity(intent);
            finish();
            return;
        }

        setContentView(R.layout.activity_main);

        editTextUsername = findViewById(R.id.username);
        editTextPassword = findViewById(R.id.Password);
        buttonLogin = findViewById(R.id.Login);

        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = editTextUsername.getText().toString().trim();
                Log.v("Username", "Username: " + username);
                String password = editTextPassword.getText().toString().trim();

                // Perform login action by sending a POST request to the server
                performLogin(username, password);
            }
        });
    }

    private String performLogin(String username, String password) {
        // Update URL with your server address and port (replace with yours)
        String url = "http://192.168.195.120:3000/login"; // Assuming port 3000 based on previous info

        try {
            JSONObject requestData = new JSONObject();
            requestData.put("idusername", username);
            requestData.put("password", password);

            LoginTask loginTask = new LoginTask();
            loginTask.execute(url, requestData.toString());

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return url;
    }

    private class LoginTask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... params) {
            String url = params[0];
            String requestData = params[1];
            String result = ""; // Diinisialisasi sebagai string kosong

            try {
                Log.v("LoginTask", "Sending request to URL: " + url);
                Log.v("LoginTask", "Request data: " + requestData);
                URL apiUrl = new URL(url);
                HttpURLConnection connection = (HttpURLConnection) apiUrl.openConnection();
                connection.setRequestMethod("POST");
                connection.setRequestProperty("Content-Type", "application/json");
                connection.setDoOutput(true);
                OutputStream outputStream = connection.getOutputStream();
                outputStream.write(requestData.getBytes());
                outputStream.flush();
                outputStream.close();

                int responseCode = connection.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    InputStream inputStream = connection.getInputStream();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                    String line;
                    StringBuilder response = new StringBuilder();

                    while ((line = bufferedReader.readLine()) != null) {
                        response.append(line);
                    }

                    bufferedReader.close();
                    result = response.toString();

                    // Tambahkan log untuk mencetak respons yang diterima
                    Log.v("LoginTask", "Response: " + result);
                } else {
                    result = "Error: " + responseCode;
                }
            } catch (IOException e) {
                e.printStackTrace();
                result = "Error: Network Error"; // Pesan error untuk jaringan
            } catch (Exception e) {
                e.printStackTrace();
                result = "Error: Unknown Error"; // Pesan error umum
            }

            return result;
        }

        @Override
        protected void onPostExecute(String result) {

            Log.v("result on post exe", "Response from server: " + result);
            String message = null;
            try {
                // Check if the response contains the string "Login"
                if (result.equals("Login successful")) {
                    // If it does, it indicates an error response, so display an error message
                    Log.v("Rcoba success", "Response from server: " + result);
                    Toast.makeText(login.this, result, Toast.LENGTH_SHORT).show();

                    SharedPreferences sharedPreferences = getSharedPreferences("loginPrefs", Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putBoolean("isLoggedIn", true);
                    editor.putString("username", editTextUsername.getText().toString().trim()); // Simpan username
                    editor.apply();
                    // Log.v("LoginStatus", "isLoggedIn set to true: " + sharedPreferences.getBoolean("isLoggedIn", false));
                    Log.v("UsernameSaved", "Username saved in SharedPreferences: " + editTextUsername.getText().toString().trim());

                    Log.v("Sh", "Username berhasil disimpan: " + editTextUsername.getText().toString().trim());
                    // Cetak username yang disimpan ke LogCat

                    // Pindah ke MainMenuActivity
                    Log.v("StartActivity", "Starting Farm activity"); // Tambahkan pesan log ini
                    Intent intent = new Intent(login.this, Farm.class);
                    startActivity(intent);
                    finish(); // Periksa apakah perintah finish() ada di sini
                    Log.v("FinishActivity", "Current activity finished"); // Tambahkan pesan log ini

                } else {
                    // Otherwise, the response is assumed to be a valid JSON object
                    // Tambahkan pesan log ini
                    Log.v("Responssadasdasa", "Response from server: " + result);
                    JSONObject responseJson = new JSONObject(result);
                    int status = responseJson.optInt("status");
                    message = responseJson.optString("response");
                    Toast.makeText(login.this, message, Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
                //     Toast.makeText(login.this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
    }
}