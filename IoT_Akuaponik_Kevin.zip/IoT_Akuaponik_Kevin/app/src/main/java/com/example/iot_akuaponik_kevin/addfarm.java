package com.example.iot_akuaponik_kevin;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class addfarm extends AppCompatActivity {

    private SharedPreferences sharedPreferences;
    private String username;

    private static final String SERVER_IP = "192.168.195.120";
    private static final String ADD_FARM_URL = "http://" + SERVER_IP + ":3000/akuaponik";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.farm); // Asumsikan Anda memiliki layout named 'farm'

        // Inisialisasi SharedPreferences di dalam onCreate()
        sharedPreferences = getSharedPreferences("loginPrefs", Context.MODE_PRIVATE);
        Log.v("SharedPreferences", "SharedPreferences initialized");

        final EditText editTextFarmName = findViewById(R.id.editText_farm_name);
        Button saveFarmButton = findViewById(R.id.button_save_farm);

        saveFarmButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String farmName = editTextFarmName.getText().toString();
                if (!farmName.isEmpty()) {
                    editTextFarmName.setEnabled(false); // Menonaktifkan EditText
                    saveFarmButton.setEnabled(false); // Menonaktifkan tombol Save
                    username = sharedPreferences.getString("username", "default_username");
                    sendFarmDataToServer(farmName, username);
                } else {
                    Toast.makeText(addfarm.this, "Nama farm tidak boleh kosong", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Mengaktifkan kembali EditText dan tombol Save ketika activity ditampilkan kembali
        EditText editTextFarmName = findViewById(R.id.editText_farm_name);
        Button saveFarmButton = findViewById(R.id.button_save_farm);
        editTextFarmName.setEnabled(true);
        saveFarmButton.setEnabled(true);
    }

    private void sendFarmDataToServer(String name, String username) {
        SendFarmDataTask task = new SendFarmDataTask();
        task.execute(name, username);
    }

    private class SendFarmDataTask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... params) {
            String nama_farm = params[0];
            String username = params[1];
            String response = "";

            try {
                URL url = new URL(ADD_FARM_URL);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setRequestProperty("Content-Type", "application/json");
                connection.setDoOutput(true);

                // Kirim data farm bersama dengan username
                String requestBody = "{\"nama_farm\":\"" + nama_farm + "\",\"Username\":\"" + username + "\"}";

                OutputStream outputStream = connection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(outputStream));
                writer.write(requestBody);
                writer.flush();
                writer.close();

                int responseCode = connection.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK || responseCode == HttpURLConnection.HTTP_CREATED) {
                    response = "Farm saved successfully";
                } else if (responseCode == HttpURLConnection.HTTP_NOT_FOUND) {
                    response = "Failed to save farm: Username not found";
                } else {
                    response = "Failed to save farm: Server error (" + responseCode + ")";
                }
            } catch (IOException e) {
                e.printStackTrace();
                response = "Error: " + e.getMessage();
            }

            return response;
        }

        @Override
        protected void onPostExecute(String result) {
            Toast.makeText(addfarm.this, result, Toast.LENGTH_SHORT).show();
            Log.v("Response", "Server response: " + result);
            // Jika farm berhasil disimpan, kembali ke activity Farm
            if (result.equals("Farm saved successfully")) {
                finish(); // Menutup activity addfarm
            }
        }
    }
}
