package com.example.iot_akuaponik_kevin;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class sensor extends Activity {

    private TextView oxygenTextView;
    private TextView turbidityTextView;
    private TextView solenoid;
    private TextView aerator;
    private LineChart chart;

    private String idKolam;

    private static final String SENSOR_ENDPOINT = "http://192.168.195.120:3000/sensor";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sensor);

        oxygenTextView = findViewById(R.id.OksigenValue);
        turbidityTextView = findViewById(R.id.KekeruhanValue);
        solenoid = findViewById(R.id.solenoid_txt);
        aerator = findViewById(R.id.aerator_txt);
        chart = findViewById(R.id.chart);

        Intent intent = getIntent();
        idKolam = intent.getStringExtra("idkolam");

        if (idKolam == null) {
            SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
            idKolam = sharedPreferences.getString("idkolam", null);
        }

        if (idKolam != null) {
            SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString("idkolam", idKolam);
            editor.apply();
        } else {
            Toast.makeText(this, "ID Kolam not found!", Toast.LENGTH_SHORT).show();
            return;
        }

        Log.v("sensor", "Received idkolam: " + idKolam);

        fetchSensorDataFromServer();

        solenoid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent solenoidIntent = new Intent(sensor.this, solenoid.class);
                solenoidIntent.putExtra("idkolam", idKolam);
                startActivity(solenoidIntent);
            }
        });

        aerator.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent aeratorIntent = new Intent(sensor.this, aerator.class);
                aeratorIntent.putExtra("idkolam", idKolam);
                startActivity(aeratorIntent);
            }
        });

        setupChart();
    }

    private void setupChart() {
        chart.getDescription().setEnabled(false);
        chart.setTouchEnabled(true);
        chart.setDragEnabled(true);
        chart.setScaleEnabled(true);
        chart.setDrawGridBackground(false);
        chart.setPinchZoom(true);

        XAxis xAxis = chart.getXAxis();
        xAxis.setTextColor(Color.BLACK);
        xAxis.setDrawGridLines(false);
        xAxis.setAvoidFirstLastClipping(true);

        YAxis leftAxis = chart.getAxisLeft();
        leftAxis.setTextColor(Color.BLACK);
        leftAxis.setAxisMaximum(100f);
        leftAxis.setAxisMinimum(0f);
        leftAxis.setDrawGridLines(true);

        YAxis rightAxis = chart.getAxisRight();
        rightAxis.setEnabled(false);

        Legend legend = chart.getLegend();
        legend.setForm(Legend.LegendForm.LINE);
        legend.setTextColor(Color.BLACK);
    }

    public void fetchSensorDataFromServer() {
        new FetchSensorDataTask().execute(idKolam);
    }

    private class FetchSensorDataTask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... params) {
            String idKolam = params[0];
            String apiUrl = SENSOR_ENDPOINT + "/" + idKolam;

            try {
                URL url = new URL(apiUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");

                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();

                Log.v("FetchSensorDataTask", "Server response: " + response.toString());

                return response.toString();
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(String jsonData) {
            if (jsonData != null) {
                try {
                    JSONArray jsonArray = new JSONArray(jsonData);
                    if (jsonArray.length() > 0) {
                        float latestTurbidity = 0;
                        float latestOxygen = 0;
                        String latestTurbidityTimestamp = "";
                        String latestOxygenTimestamp = "";

                        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.getDefault());

                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject jsonObject = jsonArray.getJSONObject(i);
                            String sensorType = jsonObject.optString("jenis_sensor", "");
                            float value = (float) jsonObject.optDouble("value", 0);
                            String timestamp = jsonObject.optString("timestamp", "");

                            if (sensorType.equals("kekeruhan")) {
                                if (latestTurbidityTimestamp.isEmpty() || sdf.parse(timestamp).after(sdf.parse(latestTurbidityTimestamp))) {
                                    latestTurbidity = value;
                                    latestTurbidityTimestamp = timestamp;
                                }
                            } else if (sensorType.equals("oksigen")) {
                                if (latestOxygenTimestamp.isEmpty() || sdf.parse(timestamp).after(sdf.parse(latestOxygenTimestamp))) {
                                    latestOxygen = value;
                                    latestOxygenTimestamp = timestamp;
                                }
                            }
                        }

                        // Set nilai terbaru ke TextView
                        turbidityTextView.setText(String.valueOf(latestTurbidity));
                        oxygenTextView.setText(String.valueOf(latestOxygen));

                        // Tambahkan data ke chart
                        addDataToChart(jsonArray);
                    } else {
                        Log.v("FetchSensorDataTask", "No sensor data found for the given idKolam.");
                    }
                } catch (JSONException | java.text.ParseException e) {
                    e.printStackTrace();
                    Toast.makeText(sensor.this, "Error parsing data", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(sensor.this, "Failed to fetch sensor data", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void addDataToChart(JSONArray jsonArray) throws JSONException, java.text.ParseException {
        List<Entry> oxygenEntries = new ArrayList<>();
        List<Entry> turbidityEntries = new ArrayList<>();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.getDefault());

        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject jsonObject = jsonArray.getJSONObject(i);
            String sensorType = jsonObject.optString("jenis_sensor", "");
            float value = (float) jsonObject.optDouble("value", 0);
            String timestamp = jsonObject.optString("timestamp", "");
            Date date = sdf.parse(timestamp);
            float timeInMillis = date.getTime();

            if (sensorType.equals("kekeruhan")) {
                turbidityEntries.add(new Entry(timeInMillis, value));
            } else if (sensorType.equals("oksigen")) {
                oxygenEntries.add(new Entry(timeInMillis, value));
            }
        }

        LineDataSet turbidityDataSet = new LineDataSet(turbidityEntries, "Kekeruhan");
        turbidityDataSet.setColor(Color.BLUE);
        turbidityDataSet.setLineWidth(2f);

        LineDataSet oxygenDataSet = new LineDataSet(oxygenEntries, "Oksigen");
        oxygenDataSet.setColor(Color.RED);
        oxygenDataSet.setLineWidth(2f);

        LineData data = new LineData(turbidityDataSet, oxygenDataSet);
        chart.setData(data);
        chart.invalidate(); // Refresh chart
    }


    private boolean isValidNumber(String value) {
            try {
                Float.parseFloat(value);
                return true;
            } catch (NumberFormatException e) {
                return false;
            }
        }
    }






// AsyncTask untuk mengambil data solenoid
   // private class FetchSolenoidDataTask extends AsyncTask<String, Void, String> {

     //   @Override
       // protected String doInBackground(String... params) {
         //   String idKolam = params[0];
           // String apiUrl = SOLENOID_ENDPOINT + "/" + idKolam;

           // try {
             //   URL url = new URL(apiUrl);
               // HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                //connection.setRequestMethod("GET");

               // BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
               // StringBuilder response = new StringBuilder();
               // String line;
                // while ((line = reader.readLine()) != null) {
                   // response.append(line);
                // }
                // reader.close();

               // Log.v("FetchSolenoidDataTask", "Server response: " + response.toString());

               // return response.toString();
           // } catch (IOException e) {
             //   e.printStackTrace();
               // return null;
           // }
       // }

//        @Override
//        protected void onPostExecute(String jsonData) {
//            if (jsonData != null) {
//                try {
//                    JSONArray jsonArray = new JSONArray(jsonData);
//                    if (jsonArray.length() > 0) {
///                        JSONObject jsonObject = jsonArray.getJSONObject(0);
//                        Log.v("FetchSolenoidDataTask", "JSON data: " + jsonObject.toString());

                        // Assuming the JSON response has the following structure:
                        // {
                        //     "solenoid": 1
                        // }

                        // Update solenoid status
//                        String solenoidStatus = jsonObject.optInt("solenoid", -1) == 0 ? "off" : "on";
//
//                        solenoidTextView.setText(solenoidStatus);
///
//                        Log.v("FetchSolenoidDataTask", "Updated TextView with solenoid status.");
//
//                    } else {
//                        Log.v("FetchSolenoidDataTask", "No solenoid data found for the given idKolam.");
//                    }
//                } catch (JSONException e) {
//                    e.printStackTrace();
//                    Toast.makeText(sensor.this, "Error parsing data", Toast.LENGTH_SHORT).show();
//                }
//            } else {
//                Toast.makeText(sensor.this, "Failed to fetch solenoid data", Toast.LENGTH_SHORT).show();
//            }
//        }
//    }

    // AsyncTask untuk mengambil data aerator
  //  private class FetchAeratorDataTask extends AsyncTask<String, Void, String> {

//        @Override
//        protected String doInBackground(String... params) {
//            String idKolam = params[0];
//            String apiUrl = AERATOR_ENDPOINT + "/" + idKolam;
//
//            try {
//                URL url = new URL(apiUrl);
//                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
//                connection.setRequestMethod("GET");
//
//                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
//                StringBuilder response = new StringBuilder();
//                String line;
//                while ((line = reader.readLine()) != null) {
//                    response.append(line);
//                }
//                reader.close();
//
//                Log.v("FetchAeratorDataTask", "Server response: " + response.toString());
//
//                return response.toString();
//            } catch (IOException e) {
//                e.printStackTrace();
//                return null;
//            }
//        }
//
//        @Override
//        protected void onPostExecute(String jsonData) {
//            if (jsonData != null) {
//                try {
//                    JSONArray jsonArray = new JSONArray(jsonData);
//                    if (jsonArray.length() > 0) {
//                        JSONObject jsonObject = jsonArray.getJSONObject(0);
//                        Log.v("FetchAeratorDataTask", "JSON data: " + jsonObject.toString());
//
//                         Assuming the JSON response has the following structure:
//                         {
//                             "aerator": 1
//                         }

//                         Update aerator status
//                        String aeratorStatus = jsonObject.optInt("boolean", -1) == 0 ? "off" : "on";

//                        aeratorTextView.setText(aeratorStatus);

//                        Log.v("FetchAeratorDataTask", "Updated TextView with aerator status.");
//
//                    } else {
//                        Log.v("FetchAeratorDataTask", "No aerator data found for the given idKolam.");
//                        aeratorTextView.setText("off"); // Set default status to off
//                    }
//                } catch (JSONException e) {
//                    e.printStackTrace();
//                    Toast.makeText(sensor.this, "Error parsing data", Toast.LENGTH_SHORT).show();
//                    aeratorTextView.setText("off"); // Set default status to off in case of JSON parsing error
//                }
//            } else {
//                Toast.makeText(sensor.this, "Failed to fetch aerator data", Toast.LENGTH_SHORT).show();
//                aeratorTextView.setText("off"); // Set default status to off in case of data fetch failure
//            }
//        }
//    }
//}
