package com.example.iot_akuaponik_kevin;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class adddevice extends AppCompatActivity {

    private LinearLayout containerLayout;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.device);

        Log.v("adddevice", "onCreate");

        // Inisialisasi container layout
        containerLayout = findViewById(R.id.dynamic);

        // Mulai task untuk mengambil data user dari server
        new FetchUserDataTask().execute();
    }

    // AsyncTask untuk mengambil data user dari server
    private class FetchUserDataTask extends AsyncTask<Void, Void, String> {

        @Override
        protected String doInBackground(Void... voids) {
            Log.v("FetchUserDataTask", "doInBackground");

            // URL endpoint untuk mengambil data user dari server
            String apiUrl = "http://192.168.1.8/users";

            try {
                // Buat koneksi HTTP
                URL url = new URL(apiUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");

                // Baca respons dari server
                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();

                // Kembalikan data JSON sebagai string
                return response.toString();
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(String jsonData) {
            Log.v("FetchUserDataTask", "onPostExecute");

            if (jsonData != null) {
                try {
                    // Parsing data JSON
                    JSONArray usersArray = new JSONArray(jsonData);

                    for (int i = 0; i < usersArray.length(); i++) {
                        JSONObject userObj = usersArray.getJSONObject(i);
                        String username = userObj.getString("username");

                        // Buat tombol untuk setiap user
                        Button button = new Button(adddevice.this);
                        button.setText(username);
                        button.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                String selectedUsername = ((Button) view).getText().toString();

                                // Lakukan sesuatu dengan selectedUsername
                                Toast.makeText(adddevice.this, "Selected user: " + selectedUsername, Toast.LENGTH_SHORT).show();
                            }
                        });
                        containerLayout.addView(button);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } else {
                // Handle kesalahan saat mengambil data user
                Toast.makeText(adddevice.this, "Failed to fetch user data", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
