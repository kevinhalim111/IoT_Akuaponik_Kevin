package com.example.iot_akuaponik_kevin;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class Farm extends AppCompatActivity {

    private LinearLayout containerLayout;
    private String username; // Menyimpan username dari Shared Preference

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dashboard_farm);

        Log.v("Farm", "onCreate");

        // Inisialisasi container layout
        containerLayout = findViewById(R.id.dynamic);

        // Mengambil username dari Shared Preference
        SharedPreferences sharedPreferences = getSharedPreferences("loginPrefs", Context.MODE_PRIVATE);
        username = sharedPreferences.getString("username", "");
        Log.v("Farm", "Username from SharedPreferences: " + username);

        // Tambahkan aksi untuk tombol tambah farm
        Button addButton = findViewById(R.id.button_add_farm);
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Intent untuk berpindah ke AddFarm Activity
                Intent intent = new Intent(Farm.this, addfarm.class);
                startActivity(intent);
            }
        });

        // Tambahkan aksi untuk tombol "Request"
        Button requestButton = findViewById(R.id.buttonlogout);
        requestButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Hapus Shared Preference saat tombol logout ditekan
                SharedPreferences sharedPreferences = getSharedPreferences("loginPrefs", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.clear(); // Hapus semua data dari Shared Preference
                editor.apply();

                // Intent untuk berpindah ke kelas MainActivity (layar login)
                Intent intent = new Intent(Farm.this, MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK); // Hapus stack aktivitas sebelumnya
                startActivity(intent);
                finish(); // Selesaikan aktivitas Farm
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.v("Farm", "onResume");

        // Mulai task untuk mengambil data farm dari server
        new FetchFarmDataTask().execute(); // Pass 'this' to the task
    }

    // AsyncTask untuk mengambil data farm dari server
    private class FetchFarmDataTask extends AsyncTask<Void, Void, String> {

        @Override
        protected String doInBackground(Void... voids) {
            Log.v("FetchFarmDataTask", "doInBackground");

            // URL endpoint untuk mengambil data farm dari server berdasarkan username
            String apiUrl = "http://192.168.195.120:3000/data/" + username;

            try {
                // Buat koneksi HTTP
                URL url = new URL(apiUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");

                // Baca respons dari server
                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();

                // Kembalikan data JSON sebagai string
                return response.toString();
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(String jsonData) {
            Log.v("FetchFarmDataTask", "onPostExecute");

            if (jsonData != null) {
                // Hapus semua tampilan yang ada di container layout sebelum menambahkan yang baru
                containerLayout.removeAllViews();

                try {
                    // Parsing data JSON
                    JSONArray farmsArray = new JSONArray(jsonData);

                    for (int i = 0; i < farmsArray.length(); i++) {
                        JSONObject farmObj = farmsArray.getJSONObject(i);
                        String farmName = farmObj.getString("nama_farm");
                        String idAkuaponik = farmObj.getString("idakuaponik"); // Assuming "idakuaponik" exists in JSON

                        Button button = new Button(Farm.this);
                        button.setText(farmName);
                        button.setTag(idAkuaponik); // Set the idakuaponik as the tag
                        button.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                String farmName = ((Button) view).getText().toString();
                                String idAkuaponik = (String) view.getTag(); // Retrieve the idakuaponik from the tag

                                // Intent untuk berpindah ke kelas "kolam" dan mengirim data tambahan
                                Intent intent = new Intent(Farm.this, kolam.class);
                                intent.putExtra("idAkuaponik", idAkuaponik); // Mengirim idakuaponik ke kelas "kolam"
                                intent.putExtra("farmName", farmName); // Mengirim nama farm ke kelas "kolam"
                                startActivity(intent); // Mulai aktivitas baru
                            }
                        });
                        containerLayout.addView(button);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } else {
                // Handle kesalahan saat mengambil data farm
                Toast.makeText(Farm.this, "Failed to fetch farm data", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
